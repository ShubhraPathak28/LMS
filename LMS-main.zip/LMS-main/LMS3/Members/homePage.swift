//
//  net.swift
//  new
//
//  Created by Aditya Majumdar on 07/05/24.
//

import SwiftUI
import Firebase
import SDWebImageSwiftUI

struct homePage: View {
    @State private var booksWithRatings: [(book: Book, averageRating: Double)] = []
    @State private var topPicks: [Book] = []
    @State private var topPicksAuthor: [Book] = []
    @State private var currentIssues: [BookInfo] = []
    @State private var returnedBooks: [BookInfo] = []
    @State private var userName: String?
    @State private var isAccountScreenPresented = false
    private var uid: String?
    
    private let db = Firestore.firestore()
    
    init() {
        if let currentUser = Auth.auth().currentUser {
            uid = currentUser.uid
        }
    }
    
    
    private func fetchBooks() {
        topPicks.removeAll()
        topPicksAuthor.removeAll()
        currentIssues.removeAll()
        returnedBooks.removeAll()
        // Fetching top rated books
        db.collection("books")
            .getDocuments { snapshot, error in
                // Handle error
                guard let documents = snapshot?.documents else { return }
                var fetchedBooks: [Book] = []
                for document in documents {
                    let data = document.data()
                    let isbn = data["isbn"] as? String ?? ""
                    let title = data["title"] as? String ?? ""
                    let description = data["description"] as? String ?? ""
                    let edition = data["edition"] as? String ?? ""
                    let genre = data["genre"] as? String ?? ""
                    let selectedCategory = data["selectedCategory"] as? String ?? ""
                    let quantity = data["quantity"] as? Int ?? 0
                    let availability = data["availability"] as? Int ?? 0
                    let publicationDate = data["publicationDate"] as? String ?? ""
                    let publisher = data["publisher"] as? String ?? ""
                    let authors = data["authors"] as? [String] ?? []
                    let imageUrl = data["imageUrl"] as? String ?? ""
                    let price = data["price"] as? Double ?? 0.0
                    let shelfNumber = data["shelfNumber"] as? String ?? ""
                    let book = Book(id: isbn, title: title, description: description, edition: edition, genre: genre, selectedCategory: selectedCategory, quantity: quantity, availability: availability, publicationDate: publicationDate, publisher: publisher, authors: authors, imageUrl: imageUrl, price: price, shelfNumber: shelfNumber)
                    fetchedBooks.append(book)
                }
                self.fetchBookRatings(for: fetchedBooks)
            }
        
        // Fetching top picks for the current user
        // Replace currentUserID with your logic to get the current user's ID
        guard let currentUserID = Auth.auth().currentUser?.uid else { return }
        
        db.collection("checkindetails")
            .whereField("memberID", isEqualTo: currentUserID)
            .getDocuments { snapshot, error in
                // Handle error
                guard let documents = snapshot?.documents else { return }
                var bookISBNs: [String] = []
                for document in documents {
                    let bookISBN = document["bookISBN"] as? String ?? ""
                    bookISBNs.append(bookISBN)
                }
                
                // Fetch books based on bookISBNs
                self.fetchBooksForISBNs(bookISBNs)
                self.fetchBooksForAuthors(bookISBNs)
            }
    }
    private func fetchUserName() {
        if let uid = uid {
            db.collection("Users").document(uid).getDocument { snapshot, error in
                guard let data = snapshot?.data(),
                      let userName = data["name"] as? String else {
                    print("Error fetching user's name: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                self.userName = userName // Assign the fetched userName to the state variable
            }
        }
    }
    
    private func fetchBooksForISBNs(_ bookISBNs: [String]) {
        var processedCategories: Set<String> = []

        for isbn in bookISBNs {
            db.collection("books")
                .whereField("isbn", isEqualTo: isbn)
                .getDocuments { snapshot, error in
                    // Handle error
                    guard let documents = snapshot?.documents else { return }
                    for document in documents {
                        let authors = document["authors"] as? [String] ?? []
                        let selectedCategory = document["selectedCategory"] as? String ?? ""

                        // Check if this category has already been processed
                        if processedCategories.contains(selectedCategory) {
                            continue // Skip fetching books for this category
                        }

                        // Mark this category as processed
                        processedCategories.insert(selectedCategory)

                        // Fetch books with same selectedCategory
                        db.collection("books")
                            .whereField("selectedCategory", isEqualTo: selectedCategory)
                            .getDocuments { snapshot, error in
                                // Handle error
                                guard let documents = snapshot?.documents else { return }
                                for document in documents {
                                    let data = document.data()
                                    let isbn = data["isbn"] as? String ?? ""
                                    let title = data["title"] as? String ?? ""
                                    let description = data["description"] as? String ?? ""
                                    let edition = data["edition"] as? String ?? ""
                                    let genre = data["genre"] as? String ?? ""
                                    let selectedCategory = data["selectedCategory"] as? String ?? ""
                                    let quantity = data["quantity"] as? Int ?? 0
                                    let availability = data["availability"] as? Int ?? 0
                                    let publicationDate = data["publicationDate"] as? String ?? ""
                                    let publisher = data["publisher"] as? String ?? ""
                                    let authors = data["authors"] as? [String] ?? []
                                    let imageUrl = data["imageUrl"] as? String ?? ""
                                    let price = data["price"] as? Double ?? 0.0
                                    let shelfNumber = data["shelfNumber"] as? String ?? ""
                                    let book = Book(id: isbn, title: title, description: description, edition: edition, genre: genre, selectedCategory: selectedCategory, quantity: quantity, availability: availability, publicationDate: publicationDate, publisher: publisher, authors: authors, imageUrl: imageUrl, price: price, shelfNumber: shelfNumber)
                                    self.topPicks.append(book)
                                }
                            }
                    }
                }
        }
    }

    
    
    private func fetchBooksForAuthors(_ bookISBNs: [String]) {
        for isbn in bookISBNs {
            db.collection("books")
                .whereField("isbn", isEqualTo: isbn)
                .getDocuments { snapshot, error in
                    // Handle error
                    guard let documents = snapshot?.documents else { return }
                    for document in documents {
                        let authors = document["authors"] as? [String] ?? []
                        // Fetch books with same authors and selectedCategory
                        db.collection("books")
                            .whereField("authors", arrayContainsAny: authors)
                            .getDocuments { snapshot, error in
                                // Handle error
                                guard let documents = snapshot?.documents else { return }
                                for document in documents {
                                    let data = document.data()
                                    let isbn = data["isbn"] as? String ?? ""
                                    let title = data["title"] as? String ?? ""
                                    let description = data["description"] as? String ?? ""
                                    let edition = data["edition"] as? String ?? ""
                                    let genre = data["genre"] as? String ?? ""
                                    let selectedCategory = data["selectedCategory"] as? String ?? ""
                                    let quantity = data["quantity"] as? Int ?? 0
                                    let availability = data["availability"] as? Int ?? 0
                                    let publicationDate = data["publicationDate"] as? String ?? ""
                                    let publisher = data["publisher"] as? String ?? ""
                                    let authors = data["authors"] as? [String] ?? []
                                    let imageUrl = data["imageUrl"] as? String ?? ""
                                    let price = data["price"] as? Double ?? 0.0
                                    let shelfNumber = data["shelfNumber"] as? String ?? ""
                                    let book = Book(id: isbn, title: title, description: description, edition: edition, genre: genre, selectedCategory: selectedCategory, quantity: quantity, availability: availability, publicationDate: publicationDate, publisher: publisher, authors: authors, imageUrl: imageUrl, price: price, shelfNumber: shelfNumber)
                                    self.topPicksAuthor.append(book)
                                }
                            }
                    }
                }
        }
    }
    
    
    
    private func fetchBookRatings(for books: [Book]) {
        var booksWithRatings: [(book: Book, averageRating: Double)] = []
        
        for book in books {
            let bookRatingRef = db.collection("BookRating").document(book.id)
            
            bookRatingRef.getDocument { document, error in
                guard let document = document, document.exists else {
                    print("BookRating document does not exist for book ID: \(book.id)")
                    // If the document doesn't exist, consider the average rating as 0
                    booksWithRatings.append((book, 0))
                    // Check if ratings are fetched for all books
                    if booksWithRatings.count == min(books.count, 10) {
                        // Sort books with ratings by average rating in descending order
                        self.booksWithRatings = booksWithRatings.sorted { $0.averageRating > $1.averageRating }
                    }
                    return
                }
                
                if let ratings = document.data()?["ratings"] as? [Double] {
                    let total = ratings.count
                    let sum = ratings.reduce(0, +)
                    let averageRating = total > 0 ? sum / Double(total) : 0
                    booksWithRatings.append((book, averageRating))
                    
                    // Check if ratings are fetched for all books
                    if booksWithRatings.count == min(books.count, 10) {
                        // Sort books with ratings by average rating in descending order
                        self.booksWithRatings = booksWithRatings.sorted { $0.averageRating > $1.averageRating }
                    }
                }
            }
        }
    }

    
    
    private func fetchBooksBorrow(uid: String) {
        currentIssues.removeAll()
        returnedBooks.removeAll()
        db.collection("checkindetails")
            .whereField("memberID", isEqualTo: uid)
            .whereField("ifcheckout", isEqualTo: "NO")
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching current issues: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                for document in documents {
                    let data = document.data()
                    let bookISBN = data["bookISBN"] as? String ?? ""
                    let issueDate = data["checkInDate"] as? String ?? ""
                    
                    // Convert issueDate string to Date
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "dd/MM/yyyy"
                    if let issueDateFormatted = dateFormatter.date(from: issueDate) {
                        // Calculate dueDate by adding 7 days
                        let dueDate = Calendar.current.date(byAdding: .day, value: 7, to: issueDateFormatted)!
                        
                        // Convert dates to "dd/MM/yyyy" format
                        let issueDateString = dateFormatter.string(from: issueDateFormatted)
                        let dueDateString = dateFormatter.string(from: dueDate)
                        
                        // Now you can proceed to fetch book info with bookISBN, issueDateString, and dueDateString
                        fetchBookInfoBorrow(bookISBN: bookISBN, issueDate: issueDateString, dueDate: dueDateString)
                    } else {
                        print("Error parsing issue date")
                    }
                }
            }
        
        db.collection("checkoutdetail")
            .whereField("memberID", isEqualTo: uid)
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching returned books: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                for document in documents {
                    let data = document.data()
                    let bookISBN = data["bookISBN"] as? String ?? ""
                    let issueDate = data["checkInDate"] as? String ?? ""
                    let dueDate = data["dueDate"] as? String ?? ""
                    let returnDate = data["returnDate"] as? String ?? ""
                    fetchBookInfoBorrow(bookISBN: bookISBN, issueDate: issueDate, returnDate: returnDate, dueDate: dueDate)
                }
            }
    }
    
    private func fetchBookInfoBorrow(bookISBN: String, issueDate: String, dueDate: String) {
        db.collection("books")
            .whereField("isbn", isEqualTo: bookISBN) // Match by ISBN
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching book info: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                
                for document in documents {
                    let data = document.data()
                    let title = data["title"] as? String ?? ""
                    let author = data["authors"] as? [String] ?? []
                    let imageUrl = data["imageUrl"] as? String ?? ""
                    let isbn = data["isbn"] as? String ?? ""
                    let bookInfo = BookInfo(isbn: isbn, title: title, author: author, imageUrl: imageUrl, issueDate: issueDate, returnDate: nil, dueDate: dueDate)
                    
                    currentIssues.append(bookInfo)
                }
            }
    }
    
    private func fetchBookInfoBorrow(bookISBN: String, issueDate: String, returnDate: String, dueDate: String) {
        db.collection("books")
            .whereField("isbn", isEqualTo: bookISBN) // Match by ISBN
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching book info: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                
                for document in documents {
                    let data = document.data()
                    let isbn = data["isbn"] as? String ?? ""
                    let title = data["title"] as? String ?? ""
                    let author = data["authors"] as? [String] ?? []
                    let imageUrl = data["imageUrl"] as? String ?? ""
                    let bookInfo = BookInfo(isbn: isbn, title: title, author: author, imageUrl: imageUrl, issueDate: issueDate, returnDate: returnDate, dueDate: dueDate)
                    
                    returnedBooks.append(bookInfo)
                }
            }
    }
    
    private func getRating(for book: BookInfo) -> Int {
        // Fetch the rating for this book from Firestore based on the user's ID and book ID
        // For now, return a default rating of 0
        return 0
    }
    
    private func updateRating(for book: BookInfo, rating: Int) {
        // Update the rating for this book in Firestore
        if let uid = uid {
            // Update MemberRating collection
            let memberRatingRef = db.collection("MemberRating").document(uid)
            memberRatingRef.setData(["\(book.isbn)": rating], merge: true)
            
            // Update BookRating collection
            let bookRatingRef = db.collection("BookRating").document(book.isbn)
            bookRatingRef.updateData(["ratings": FieldValue.arrayUnion([rating])])
        }
    }
    
    
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text("Home").font(.largeTitle).bold()
                
                Spacer()
                Image(systemName: "person.circle.fill")
                    .font(.custom("SF Pro", size: 44))
                    .padding(.trailing,10)
                    .onTapGesture {
                        isAccountScreenPresented = true
                    }
            }.padding()
            ScrollView {
                VStack(alignment: .leading, spacing: 5) {
                    if !currentIssues.isEmpty {
                        VStack(alignment: .leading) {
                            Text("Currently Issued")
                                .font(.title).bold()
                                .padding(.bottom, 10)
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(){
                                    ForEach(currentIssues) { book in
                                        BookItemView(book: book, rating: self.getRating(for: book))
                                    }
                                }
                            }
                            
                        }
                    }
                    Text("Top Rated Books")
                        .font(.title).bold()
                        .padding(.bottom, 20)
                        .padding(.top, 20)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 25) {
                            ForEach(booksWithRatings.indices, id: \.self) { index in
                                HStack(spacing: -40) {
                                    Text("\(index + 1)") // Display the number
                                        .font(
                                            Font.custom("Inter", size: 160)
                                                .weight(.heavy)
                                        )
                                        .font(.largeTitle)
                                    NavigationLink(destination: BookDetailViewMember(book: booksWithRatings[index].book)) {
                                        VStack{
                                            WebImage(url: URL(string: booksWithRatings[index].book.imageUrl))
                                                .resizable()
                                                .frame(width: 160, height: 240)
                                                .cornerRadius(5)
                                                .shadow(radius: 10)
                                        }
                                    }
                                }
                            }
                        }
                        .padding(.leading, -10)
                    }
                    
                    Text("Top Picks for You")
                        .font(.title).bold()
                        .padding(.bottom, 20)
                        .padding(.top, 20)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(topPicks.indices, id: \.self) { index in
                                
                                NavigationLink(destination: BookDetailViewMember(book: topPicks[index])) {
                                    VStack{
                                        WebImage(url: URL(string: topPicks[index].imageUrl))
                                            .resizable()
                                            .frame(width: 160, height: 240)
                                            .cornerRadius(5)
                                    }
                                }
                                
                            }
                        }
                        
                    }
                    
                    Text("Based on Past Authors")
                        .font(.title).bold()
                        .padding(.bottom, 20)
                        .padding(.top, 20)
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(topPicksAuthor.indices, id: \.self) { index in
                                
                                NavigationLink(destination: BookDetailViewMember(book: topPicksAuthor[index])) {
                                    VStack{
                                        WebImage(url: URL(string: topPicksAuthor[index].imageUrl))
                                            .resizable()
                                            .frame(width: 160, height: 240)
                                            .cornerRadius(5)
                                    }
                                }
                                
                            }
                        }
                        
                    }
                }
                .background(
                    NavigationLink(
                        destination: Account_Screen(),
                        isActive: $isAccountScreenPresented
                    ) {
                        EmptyView()
                    }
                )
            }
            .padding(.leading)
            .onAppear {
                fetchBooks()
                fetchUserName()
                if let uid = uid {
                    fetchBooksBorrow(uid: uid)
                }
                
            }
        }
    }
    //    private func getRating(for book: BookInfo) -> Int {
    //        // Fetch the rating for this book from Firestore based on the user's ID and book ID
    //        // For now, return a default rating of 0
    //        return 0
    //    }
}

#if DEBUG
struct Home_Previews: PreviewProvider {
    static var previews: some View {
        homePage()
    }
}
#endif
