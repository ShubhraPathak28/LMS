//
//  EventsPage.swift
//  LMS3
//
//  Created by Aditya Majumdar on 02/05/24.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import SDWebImageSwiftUI
import EventKit

struct EventsPage: View {
    @State private var selectedTab = "Upcoming"
    @StateObject var viewModel = EventsViewModel()
    @StateObject var viewModelRequested = EventsViewModelRequested()
    @State var isLoading = true
    @State private var showingUserEventRequestPage = false
    @State private var showingCalendarPage = false // State for showing CalendarMember view
    
    var body: some View {
        VStack {
            
            HStack {
                
                Text("Events")
                    .font(.largeTitle).bold()
                    .padding()
                Spacer()
                Button(action: {
                    showingCalendarPage.toggle()
                }) {
                    Image(systemName: "calendar")
                        .font(.title)
                        .padding()
                }
                NavigationLink(destination: UserEventRequestPage(), isActive: $showingUserEventRequestPage) {
                    Image(systemName: "plus")
                        .font(.title)
                        .padding()
                }
            }
            VStack(spacing:-2){
                HStack {
                    // Upcoming tab
                    Text("Upcoming")
                        .font(.headline)
                        .padding()
                        // Change the selectedTab state when tapped
                        .onTapGesture {
                            self.selectedTab = "Upcoming"
                        }
                        // Change the text color based on selection
                        .foregroundColor(selectedTab == "Upcoming" ? Color(red: 228/255, green: 133/255, blue: 134/255) : Color(UIColor.label))
                    
                    Spacer()
                    
                    // Requested tab
                    Text("Requested")
                        .font(.headline)
                        .padding()
                        // Change the selectedTab state when tapped
                        .onTapGesture {
                            self.selectedTab = "Requested"
                        }
                        // Change the text color based on selection
                        .foregroundColor(selectedTab == "Requested" ? Color(red: 228/255, green: 133/255, blue: 134/255) : Color(UIColor.label))
                }
                .padding(.horizontal)

                Divider()
            }
            
            // Display content based on the selected tab
            if selectedTab == "Upcoming" {
                VStack() {
                    if isLoading {
                        ProgressView("Loading...")
                    } else {
                        if viewModel.eventRequests.isEmpty {
                            Text("No current requests")
                        } else {
                            NavigationView {
                                ScrollView{
                                    VStack {
                                        ForEach(viewModel.eventRequests) { eventRequest in
                                            UpcomingView(eventRequest: eventRequest)
                                                .padding(.vertical, 5)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer()
                }
                .onAppear {
                    viewModel.fetchEventRequests()
                }
                .onChange(of: viewModel.isLoading) { newValue in
                    isLoading = newValue
                }

            } else {
                VStack() {
                    if isLoading {
                        ProgressView("Loading...")
                    } else {
                        if viewModelRequested.eventRequests.isEmpty {
                            Text("No current requests")
                        } else {
                            NavigationView {
                                ScrollView{
                                    VStack{
                                        ForEach(viewModelRequested.eventRequests) { eventRequest in
                                            RequestedView(eventRequest: eventRequest)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer()
                }
                .onAppear {
                    if let currentUserUID = Auth.auth().currentUser?.uid {
                        viewModelRequested.fetchEventRequests(forCurrentUserUID: currentUserUID)
                    }
                }
                .onChange(of: viewModelRequested.isLoading) { newValue in
                    isLoading = newValue
                }
            }
            
            Spacer()
        }
        .padding()
        .sheet(isPresented: $showingCalendarPage) {
            CalendarMember() 
        }
    }
}

class EventsViewModel: ObservableObject {
    @Published var eventRequests: [EventRequest] = []
    @Published var isLoading = true
    
    // Fetch event requests from Firestore
    func fetchEventRequests() {
        isLoading = true
        let db = Firestore.firestore()
        
        let currentDate = Date()
        
        db.collection("eventRequests")
            .whereField("status", isEqualTo: "Accepted")
            .whereField("eventDate", isGreaterThanOrEqualTo: currentDate)
            .getDocuments { querySnapshot, error in
                self.isLoading = false
                if let error = error {
                    print("Error fetching event requests: \(error)")
                } else {
                    if let documents = querySnapshot?.documents {
                        self.eventRequests = documents.compactMap { queryDocumentSnapshot in
                            let data = queryDocumentSnapshot.data()
                            return EventRequest(
                                eventName: data["eventName"] as? String ?? "",
                                eventDate: (data["eventDate"] as? Timestamp)?.dateValue() ?? Date(),
                                eventDescription: data["eventDescription"] as? String ?? "",
                                imageUrl: data["imageUrl"] as? String ?? "",
                                memberID: data["memberID"] as? String ?? "",
                                speakerName: data["speakerName"] as? String ?? "",
                                status: EventStatus(rawValue: data["status"] as? String ?? "") ?? .pending,
                                description: data["description"] as? String ?? ""
                            )
                        }
                    }
                }
            }
    }

    
    func rsvpToEvent(eventRequest: EventRequest) {
        guard let currentUserUID = Auth.auth().currentUser?.uid else {
            print("Error: Current user UID not available.")
            return
        }
        
        let currentDate = Date() // Get the current date
        
        // Check if the event date is not before the current date
        guard eventRequest.eventDate > currentDate else {
            print("Error: Event date is before the current date.")
            return
        }
        
        let db = Firestore.firestore()
        let docRef = db.collection("eventRSVPs").document()
        
        let data: [String: Any] = [
            "eventName": eventRequest.eventName,
            "eventDate": eventRequest.eventDate,
            "eventDescription": eventRequest.eventDescription,
            "imageUrl": eventRequest.imageUrl,
            "memberID": currentUserUID // Store the current user's UID
        ]
        
        docRef.setData(data) { error in
            if let error = error {
                print("Error RSVPing to event: \(error.localizedDescription)")
            } else {
                print("RSVP successful!")
            }
        }
    }
}


class EventsViewModelRequested: ObservableObject {
    @Published var eventRequests: [EventRequest] = []
    @Published var isLoading = true
    
    // Fetch event requests from Firestore for the current user
    func fetchEventRequests(forCurrentUserUID uid: String) {
        isLoading = true
        let db = Firestore.firestore()
        // Query for event requests where memberID matches the current user's ID
        db.collection("eventRequests")
            .whereField("memberID", isEqualTo: uid)
            .getDocuments { querySnapshot, error in
                self.isLoading = false
                if let error = error {
                    print("Error fetching requested event requests: \(error)")
                } else {
                    if let documents = querySnapshot?.documents {
                        // Convert Firestore documents to EventRequest objects
                        self.eventRequests = documents.compactMap { queryDocumentSnapshot in
                            let data = queryDocumentSnapshot.data()
                            return EventRequest(
                                eventName: data["eventName"] as? String ?? "",
                                eventDate: (data["eventDate"] as? Timestamp)?.dateValue() ?? Date(),
                                eventDescription: data["eventDescription"] as? String ?? "",
                                imageUrl: data["imageUrl"] as? String ?? "",
                                memberID: data["memberID"] as? String ?? "",
                                speakerName: data["speakerName"] as? String ?? "",
                                status: EventStatus(rawValue: data["status"] as? String ?? "") ?? .pending,
                                description: data["description"] as? String ?? ""
                            )
                        }
                        // Sort the event requests based on event date (latest to oldest)
                        self.eventRequests.sort(by: { $0.eventDate > $1.eventDate })
                    }
                }
            }
    }
    func rsvpToEvent(eventRequest: EventRequest) {
            guard let currentUserUID = Auth.auth().currentUser?.uid else {
                print("Error: Current user UID not available.")
                return
            }
            
            let currentDate = Date() // Get the current date
            
            // Check if the event date is not before the current date
            guard eventRequest.eventDate > currentDate else {
                print("Error: Event date is before the current date.")
                return
            }
            
            let db = Firestore.firestore()
            let docRef = db.collection("eventRSVPs").document()
            
            let data: [String: Any] = [
                "eventName": eventRequest.eventName,
                "eventDate": eventRequest.eventDate,
                "eventDescription": eventRequest.eventDescription,
                "imageUrl": eventRequest.imageUrl,
                "memberID": currentUserUID // Store the current user's UID
            ]
            
            docRef.setData(data) { error in
                if let error = error {
                    print("Error RSVPing to event: \(error.localizedDescription)")
                } else {
                    print("RSVP successful!")
                    
                    // Save the event to the calendar
                    let eventStore = EKEventStore()
                    eventStore.requestAccess(to: .event) { granted, error in
                        if granted && error == nil {
                            let event = EKEvent(eventStore: eventStore)
                            event.title = eventRequest.eventName
                            event.startDate = eventRequest.eventDate
                            event.endDate = eventRequest.eventDate.addingTimeInterval(3600) // Assuming event duration is one hour
                            event.notes = eventRequest.eventDescription
                            event.calendar = eventStore.defaultCalendarForNewEvents
                            
                            do {
                                try eventStore.save(event, span: .thisEvent)
                                print("Event saved to calendar!")
                            } catch let error as NSError {
                                print("Failed to save event to calendar: \(error.localizedDescription)")
                            }
                        } else {
                            print("Access to calendar denied or error occurred: \(error?.localizedDescription ?? "")")
                        }
                    }
                }
            }
        }
}


struct UpcomingView: View {
    @StateObject var viewModel = EventsViewModel()
    @State var eventRequest: EventRequest
    @State private var isRSVPed = false // Track RSVP status
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack() {
                if let url = URL(string: eventRequest.imageUrl) {
                    WebImage(url: url)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 280, height: 180)
                        .cornerRadius(10)
                }
                
                VStack(alignment: .leading, spacing: 3) {
                    Text(eventRequest.eventName)
                        .font(.headline)
                        .foregroundColor(.primary)
                    
                    Text("Date: \(eventRequest.eventDate, style: .date)")
                        .font(.subheadline)
                        .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                    
                    Text(eventRequest.eventDescription)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(4)
                    
                    Button(action: {
                        if isRSVPed {
                            // User has already RSVP'd, do nothing
                            print("You are in!")
                        } else {
                            // Call a function to handle RSVP
                            viewModel.rsvpToEvent(eventRequest: eventRequest)
                            isRSVPed = true
                            
                            // Add event to calendar upon RSVP
                            addToCalendar(event: eventRequest)
                        }
                    }) {
                        ZStack{
                            Rectangle()
                                .frame(width:80,height:20)
                                .cornerRadius(5.0)
                                .foregroundColor(isRSVPed ? .clear : Color("Pink")) // Pink background if not RSVPed
                                .overlay(
                                    Text(isRSVPed ? "You are in!" : "RSVP") // Show "You are in!" if RSVPed
                                        .font(.subheadline.bold())
                                        .foregroundColor(isRSVPed ? Color("Pink") : .black)
                                        .padding(.vertical)
                                )
                        }
                    }
                    .padding(.horizontal, 100)
                }
            }
            .frame(width: 300)
            .padding()
            .overlay(RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray, lineWidth: 0.8))
        }
        .padding()
        .onAppear {
            checkRSVPStatus() // Check RSVP status on view appear
        }
    }
    
    // Function to check RSVP status from Firestore
    private func checkRSVPStatus() {
        guard let currentUserUID = Auth.auth().currentUser?.uid else {
            print("Error: Current user UID not available.")
            return
        }
        
        let db = Firestore.firestore()
        let query = db.collection("eventRSVPs").whereField("memberID", isEqualTo: currentUserUID).whereField("eventName", isEqualTo: eventRequest.eventName)
        
        query.getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching RSVP status: \(error.localizedDescription)")
                return
            }
            
            guard let documents = snapshot?.documents else {
                print("No documents found")
                return
            }
            
            // If documents exist, user has RSVP'd
            isRSVPed = !documents.isEmpty
        }
    }
    
    // Function to add event to calendar using EventKit
    private func addToCalendar(event: EventRequest) {
        let eventStore = EKEventStore()
        eventStore.requestAccess(to: .event) { granted, error in
            if granted && error == nil {
                let event = EKEvent(eventStore: eventStore)
                event.title = eventRequest.eventName
                event.startDate = eventRequest.eventDate
                event.endDate = eventRequest.eventDate.addingTimeInterval(3600) // Assuming event duration is one hour
                event.notes = eventRequest.eventDescription
                event.calendar = eventStore.defaultCalendarForNewEvents
                
                do {
                    try eventStore.save(event, span: .thisEvent)
                    print("Event saved to calendar!")
                } catch let error as NSError {
                    print("Failed to save event to calendar: \(error.localizedDescription)")
                }
            } else {
                print("Access to calendar denied or error occurred: \(error?.localizedDescription ?? "")")
            }
        }
    }
}

struct RequestedView: View {
    @ObservedObject var viewModel = EventsViewModelRequested()
    @State var eventRequest: EventRequest
    @State private var showingDetailSheet = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Display event details here
            VStack{
                if let url = URL(string: eventRequest.imageUrl) {
                    WebImage(url: url)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 280, height: 180)
                        .cornerRadius(10)
                }
                
                VStack(alignment: .leading, spacing: 3) {
                    HStack {
                                            Text(eventRequest.eventName)
                                                .font(.headline)
                                                .foregroundColor(.primary)
                                            
                                            if eventRequest.hasDescription {
                                                Image(systemName: "message.fill")
                                                    .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                                            }
                                        }
                    Text("Date: \(eventRequest.eventDate, style: .date)")
                        .font(.subheadline)
                        .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                    
                    Text(eventRequest.eventDescription)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(4)
                    
                    
                    HStack(spacing:50){
                        Text("Current Status: ")
                            .font(.headline)
                        statusBox(for: eventRequest.status)
                            .frame(width: 100, height: 30)
                    }
                }
                
            }
            .frame(width:300)
            .padding()
            .overlay(RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray, lineWidth: 0.8))
            
        }.padding()
            .onTapGesture {
                        showingDetailSheet.toggle()
                    }
                    .sheet(isPresented: $showingDetailSheet) {
                        EventDetailSheet(eventRequest: eventRequest)
                    }
       
    }
    private func statusBox(for status: EventStatus) -> some View {
            var color: Color
            var statusText: String
            
            switch status {
            case .pending:
                color = Color.yellow
                statusText = "Pending"
            case .accepted:
                color = Color.green
                statusText = "Accepted"
            case .rejected:
                color = Color.red
                statusText = "Rejected"
            }
            
            return Text(statusText)
                .foregroundColor(.white)
                .padding(5)
                .background(color)
                .cornerRadius(5)
                .padding(.leading, 5)
        }
}

struct EventsPage_Previews: PreviewProvider {
    static var previews: some View {
        EventsPage()
    }
}
