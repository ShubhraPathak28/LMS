//
//  Comments.swift
//  LMS3
//
//  Created by Aditya Majumdar on 30/04/24.
//

import SwiftUI
import FirebaseFirestore
import FirebaseFirestoreSwift

struct Comment: Identifiable, Codable {
    @DocumentID var id: String?
    var uid: String
    var username: String
    var text: String
    var timestamp: Timestamp
}

struct CommentView: View {
    var communityID: String
    var userID: String
    @State private var newCommentText = ""
    @ObservedObject private var commentViewModel = CommentViewModel()
    @State private var username: String = ""
    var body: some View {
        VStack {
            List(commentViewModel.comments) { comment in
                VStack(alignment: .leading) {
                    Text(comment.username)
                        .font(.headline)
                    Text(comment.text)
                        .font(.body)
                        .foregroundColor(.secondary)
                }
            }
            
            HStack {
                TextField("Add a comment", text: $newCommentText)
                    .padding(.horizontal)
                Button("Post") {
                    let newComment = Comment(uid: userID, username: username, text: newCommentText, timestamp: Timestamp())
                    commentViewModel.addComment(newComment, toTweetWithID: communityID)
                    
                    newCommentText = ""
                }
            }
            .padding()
            .background(Color.secondary.opacity(0.1))
        }
        .onAppear {
            commentViewModel.fetchComments(forTweetWithID: communityID)
            getUsername(forUID: userID) { fetchedUsername in
                if let fetchedUsername = fetchedUsername {
                    self.username = fetchedUsername
                }
            }
        }
        .navigationBarTitle("Comments", displayMode: .inline)
    }
}


class CommentViewModel: ObservableObject {
    private var db = Firestore.firestore()

    @Published var comments: [Comment] = []

    func fetchComments(forTweetWithID tweetID: String) {
        db.collection("posts").document(tweetID).collection("comments").order(by: "timestamp", descending: true).addSnapshotListener { snapshot, error in
            guard let documents = snapshot?.documents else {
                print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            self.comments = documents.compactMap { document in
                do {
                    let comment = try document.data(as: Comment.self)
                    return comment
                } catch {
                    print("Error decoding comment: \(error.localizedDescription)")
                    return nil
                }
            }
        }
    }
    
    func addComment(_ comment: Comment, toTweetWithID tweetID: String) {
        do {
            try db.collection("posts").document(tweetID).collection("comments").addDocument(from: comment)
        } catch {
            print("Error adding comment: \(error.localizedDescription)")
        }
    }
}
