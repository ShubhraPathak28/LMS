//
//  ReserveBookViewMember.swift
//  LMS3
//
//  Created by Aditya Majumdar on 03/05/24.
//

import SwiftUI
import EventKit
import Firebase


struct HourPicker: View {
    @Binding var selectedHour: Int
    
    var body: some View {
        Picker("", selection: $selectedHour) {
            ForEach(9..<20, id: \.self) { hour in
                let displayHour = hour % 12 == 0 ? 12 : hour % 12 // Convert 24-hour format to 12-hour format
                let displayAMPM = hour < 12 ? "AM" : "PM" // Determine AM or PM
                
                Text("\(displayHour):00 \(displayAMPM)") // Display in 12-hour format with AM/PM
                    .tag(hour)
            }
        }
        .frame(width: 120, height: 35)
        .pickerStyle(MenuPickerStyle())
    }
}

struct ReserveBookViewMember: View {
    let bookTitle: String
    let bookImage: UIImage
    @State private var startDate = Date()
    @State private var endDate = Date() // Add this line
      
    
    @State private var selectedHour = 9 // Default start hour
    
    var db = Firestore.firestore()
    let eventStore = EKEventStore()
    
    

    var body: some View {
        VStack {
            ZStack {
                Rectangle()
                    .cornerRadius(10.0)
                    .foregroundColor(Color(red: 235/255, green: 235/255, blue: 240/255).opacity(0.1))
                    .frame(width: 360, height: 150)
                  //  .shadow(radius: 10)
                
                HStack {
                    // Display your book image here
                    Image(uiImage: bookImage)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width:100,height:140) // Adjust size as needed
                        .cornerRadius(10)
                        .shadow(radius: 5)
                        .padding(.top)
                        .padding(.horizontal)
                    
                    // Display your book title here
                    Text(bookTitle)
                        .font(.headline)
                        .frame(width: 180, alignment: .topLeading)
                        .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                }
            }.padding()
        Spacer()
            VStack {
                HStack {
                    Text("Date")
                        .bold()
                        .padding(10)
                    Spacer()
                    
                    
                    DatePicker("Starts", selection: $startDate, displayedComponents: .date)
                        
                        
                        .frame(width: 120)
                        .background(Color.clear)
                        .cornerRadius(10)
                        .padding()
                        .labelsHidden()
                        .disabled(false)
                        .onAppear {
                            let calendar = Calendar.current
                            let today = calendar.startOfDay(for: Date()) // Get the start of the current day
                            startDate = today // Set the start date to today
                        }
                        .onChange(of: startDate) { newStartDate in
                            // Ensure that the start date cannot be before today
                            let calendar = Calendar.current
                            let today = calendar.startOfDay(for: Date())
                            if newStartDate < today {
                                startDate = today
                            }
                        }
                }   .background(Color(red: 188/255, green: 188/255, blue: 192/255).opacity(0.5))
                    .cornerRadius(15)
                    .padding(.horizontal)
                    .cornerRadius(15)
                    .padding(.horizontal)

                HStack{
                    Text("Time Slot")
                        .bold()
                        .padding(10)
                    Spacer()
                    HourPicker(selectedHour: $selectedHour)
                        
                        .frame(width: 120)
                      //  .background(Color.clear)
                        .background(Color(red: 188/255, green: 188/255, blue: 192/255).opacity(0.4))
                        .cornerRadius(10)
                        .padding()
                        .labelsHidden()
                        .onChange(of: selectedHour) { hour in
                            let calendar = Calendar.current
                            let components = calendar.dateComponents([.year, .month, .day], from: startDate)
                            let newStartDate = calendar.date(from: components)?.addingTimeInterval(TimeInterval(hour * 3600))
                            if let newStartDate = newStartDate {
                                startDate = newStartDate
                            }
                        }
                        .onChange(of: startDate) { _ in
                                                        endDate = Calendar.current.date(byAdding: .hour, value: 1, to: startDate) ?? Date()
                                                    }
                }
                .background(Color(red: 188/255, green: 188/255, blue: 192/255).opacity(0.5))
                .cornerRadius(15)
                .padding(.horizontal)
                .cornerRadius(15)
                .padding(.horizontal)

            }
Spacer()
            Button(action: {
                // Add your action here
               
                checkBook()
                
            }) {
                Text("Reserve")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color(red: 228/255, green: 133/255, blue: 134/255))
                    .cornerRadius(8)
                    .padding(.horizontal)
            }
            .padding()
            
           Spacer()        }
        .navigationTitle("Reserve Book")
    }
    
    func reserveBookToCalendar(){
        let authorizationStatus = EKEventStore.authorizationStatus(for: .event)
        
        switch authorizationStatus {
        case .authorized:
            saveEvent()
        case .notDetermined:
            eventStore.requestAccess(to: .event) { (granted, error) in
                if granted {
                    saveEvent()
                } else {
                    print("Permission denied by the user.")
                }
            }
        case .denied, .restricted:
            print("Permission not granted to access calendar.")
        @unknown default:
            print("Unknown authorization status.")
        }
    }
    
    func saveEvent() {
        guard let userID = Auth.auth().currentUser?.uid else {
            print("User ID is nil.")
            return
        }
        let newEvent = EKEvent(eventStore: eventStore)
        newEvent.title = bookTitle
        newEvent.notes = userID
        newEvent.startDate = startDate
        newEvent.endDate = endDate

        newEvent.calendar = eventStore.defaultCalendarForNewEvents
        do {
            try eventStore.save(newEvent, span: .thisEvent)
            print("Event saved successfully.")
        } catch {
            print("Error saving event: \(error.localizedDescription)")
        }
    }
    
    func reserveBookFirebase() {
        if let userID = Auth.auth().currentUser?.uid {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy HH:mm" // Adjust the format as needed

            // Convert dates to string with desired format
            let startDateString = dateFormatter.string(from: startDate)
            let endDateString = dateFormatter.string(from: endDate)

            // Create a dictionary with event details
            let eventData: [String: Any] = [
                "bookName": bookTitle,
                "memberID": userID, // Use the current user's ID
                "startTime": startDateString,
                "endTime": endDateString
            ]

            // Add a new document with a generated ID
            db.collection("ReserveBook").addDocument(data: eventData) { error in
                if let error = error {
                    print("Error adding document: \(error)")
                } else {
                    print("Document added")
                }
            }
        } else {
            print("No user signed in")
        }
    }

    func checkBook() {
        // Check if a user is signed in
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy HH:mm"
        let startDateString = dateFormatter.string(from: startDate)
        guard let userID = Auth.auth().currentUser?.uid else {
            print("No user signed in")
            return
        }

        // Query Firestore to check if the user has already reserved a book in the selected time slot
        db.collection("ReserveBook")
            .whereField("memberID", isEqualTo: userID) // Check reservations by the current user
            .whereField("startTime", isEqualTo: startDateString)
            .getDocuments { querySnapshot, error in
                if let error = error {
                    print("Error getting documents: \(error)")
                } else {
                    // If the user has already reserved a book in this time slot, display an alert
                    if querySnapshot?.documents.count ?? 0 > 0 {
                        self.showAlert(message: "You have already reserved a book in this time slot")
                    } else {
                        // If the user has not reserved a book in this time slot, proceed to check availability
                        self.checkAvailability()
                    }
                }
            }
    }

    func checkAvailability() {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy HH:mm"
        let startDateString = dateFormatter.string(from: startDate)
        
        // Query Firestore to count the number of reservations for the selected book title and within the selected time range
        db.collection("ReserveBook")
            .whereField("bookName", isEqualTo: bookTitle)
            .whereField("startTime", isEqualTo: startDateString)
            .getDocuments { querySnapshot, error in
                if let error = error {
                    print("Error getting documents: \(error)")
                } else {
                    // If the count of reservations exceeds availability, display an alert
                    let count = querySnapshot?.documents.count ?? 0
                    
                    // Fetch availability from the Firestore document of the book
                    self.fetchAvailability(for: self.bookTitle) { availability in
                        if let availability = availability {
                            print(availability)
                            print(count)
                            if count == availability {
                                // Book is not available in selected slots, display an alert
                                self.showAlert(message: "Book is not available in selected slots")
                            } else {
                                // Book is available, proceed with reservation
                                self.reserveBookFirebase()
                                self.reserveBookToCalendar()
                                self.showAlert(message: "You have successfully reserved a book")
                            }
                        } else {
                            print("Availability not found for the book")
                        }
                    }
                }
            }
    }


    func fetchAvailability(for bookTitle: String, completion: @escaping (Int?) -> Void) {
        db.collection("books")
            .whereField("title", isEqualTo: bookTitle)
            .getDocuments { querySnapshot, error in
                if let error = error {
                    print("Error getting documents: \(error)")
                    completion(nil)
                } else {
                    guard let document = querySnapshot?.documents.first else {
                        print("Document not found for book title: \(bookTitle)")
                        completion(nil)
                        return
                    }
                    if let availability = document.data()["availability"] as? Int {
                        completion(availability)
                    } else {
                        print("Availability not found for book title: \(bookTitle)")
                        completion(nil)
                    }
                }
            }
    }

    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        UIApplication.shared.windows.first?.rootViewController?.present(alert, animated: true, completion: nil)
    }
}

struct ReserveBookViewMember_Previews: PreviewProvider {
    static var previews: some View {
        ReserveBookViewMember(bookTitle: "Book Title", bookImage: UIImage(named: "books1")!)
    }
}
