//
//  MemberQR.swift
//  LMS3
//
//  Created by Aditya Majumdar on 24/04/24.
//

import SwiftUI
import Firebase
import CoreImage

struct QRCodeView: View {
    @State private var uid: String? = nil
    @State private var qrCodeImage: UIImage? = nil
    
    var body: some View {
        VStack {
            if let qrCodeImage = qrCodeImage {
                Image(uiImage: qrCodeImage)
                    .resizable()
                    .interpolation(.none)
                    .frame(width: 200, height: 200) // Adjust size as needed
            } else {
                Text("Generating QR code...")
            }
            
            if let uid = uid {
            } else {
                Text("Fetching UID...")
            }
        }
        .onAppear {
            fetchCurrentUserUID()
        }
    }
    
    private func fetchCurrentUserUID() {
        if let user = Auth.auth().currentUser {
            let uid = user.uid
            print("User UID: \(uid)") // Print UID for debugging
            self.uid = uid
            generateQRCode(from: uid)
        } else {
            print("No user signed in.")
        }
    }
    
    private func generateQRCode(from string: String) {
        guard let data = string.data(using: .utf8) else {
            print("Failed to convert string to UTF-8 data.")
            return
        }
        
        let filter = CIFilter(name: "CIQRCodeGenerator")
        filter?.setValue(data, forKey: "inputMessage")
        
        guard let outputImage = filter?.outputImage else {
            print("Failed to generate output image from QR code filter.")
            return
        }
        
        let context = CIContext()
        guard let cgImage = context.createCGImage(outputImage, from: outputImage.extent) else {
            print("Failed to create CGImage from CIImage.")
            return
        }
        
        self.qrCodeImage = UIImage(cgImage: cgImage)
    }
}



