//
//  memberTabView.swift
//  LMS3
//
//  Created by Devansh Agarwal on 26/04/24.
//

import SwiftUI

struct memberTabView: View {
        var body: some View {
          
                TabView{
                    Group{
                      
//                        Search()
//                        .tabItem {  Label("Home", systemImage: "house.fill") }
                        homePage()
                        .tabItem {  Label("Home", systemImage: "house.fill") }

                        
                        BorrowingHistoryView()
                        .tabItem {  Label("History", systemImage: "clock") }
                        
                        EventsPage()
                        .tabItem {  Label("Events", systemImage: "calendar") }
                        
                        CommunityCloneView()
                            .tabItem {  Label("Community", systemImage: "person.3") }

                        GenreScreen()
                        .tabItem {  Label("Search", systemImage: "magnifyingglass") }
                    }
                   
                    
                   
                }.accentColor((Color(red: 228/255, green: 133/255, blue: 134/255)))
            }
        
    }


#Preview {
    memberTabView()
}
