//
//  MemberEventRequest.swift
//  LMS3
//
//  Created by Aditya Majumdar on 01/05/24.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth
import FirebaseStorage

struct UserEventRequestPage: View {
    @State private var eventName = ""
    @State private var speakerName = ""
    @State private var eventDescription = ""
    @State private var eventDate = Date()
    @State private var eventImage: Image?
    @State private var showingImagePicker = false
    @State private var inputImageData: Data?
    @State private var showingAlert = false
    
    // Define your theme color
    let themeColor = Color(red: 228/255, green: 133/255, blue: 134/255)
    
    var body: some View {
        NavigationView {
            VStack {
                Form {
                    Section(header: Text("Event Details").foregroundColor(themeColor)) {
                        TextField("Event Name", text: $eventName)
                        TextField("Speaker Name", text: $speakerName)
                        TextEditor(text: $eventDescription)
                            .frame(height: 100)
                            .overlay(
                                RoundedRectangle(cornerRadius: 5)
                                    .stroke(themeColor, lineWidth: 1)
                            )
                            .padding(.horizontal, 4)                            .padding(.vertical, 8)
                            .overlay(
                                ZStack(alignment: .topLeading) {
                                    if eventDescription.isEmpty {
                                        Text("Event Description") // Placeholder text
                                            .foregroundColor(.gray)
                                            .padding(.horizontal, 8)
                                            .padding(.vertical, 8)
                                    }
                                }
                            )
                        DatePicker("Event Date", selection: $eventDate, in: Date()..., displayedComponents: .date)
                    }
                    
                    Section(header: Text("Event Photo").foregroundColor(themeColor)) {
                        ZStack {
                            if let eventImage = eventImage {
                                eventImage
                                    .resizable()
                                    .scaledToFit()
                            } else {
                                Text("Tap to select a photo")
                                    .foregroundColor(.gray)
                                    .padding()
                            }
                        }
                        .onTapGesture {
                            showingImagePicker = true
                        }
                    }
                }
                .accentColor(themeColor) // Change accent color of the form
                
                Spacer() // Pushes the button to the bottom
                
                Button("Submit Request") {
                    submitRequest()
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(themeColor) // Use the theme color here
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
            }
            .navigationBarTitle("Request an Event")
            
            .sheet(isPresented: $showingImagePicker, onDismiss: loadImage) {
                ImagePickerEvent(imageData: $inputImageData)
            }
        }
        .accentColor(themeColor)
        .alert(isPresented: $showingAlert) {
            Alert(title: Text("Success"), message: Text("Event request submitted successfully!"), dismissButton: .default(Text("OK")))
        }
    }
    
    private func loadImage() {
        guard let inputData = inputImageData, let uiImage = UIImage(data: inputData) else { return }
        eventImage = Image(uiImage: uiImage)
    }
    
    private func submitRequest() {
        // Get the current user's UID
        guard let currentUserID = Auth.auth().currentUser?.uid else {
            print("User not authenticated")
            return
        }
        
        // Create a dictionary with event details
        var eventData: [String: Any] = [
            "eventName": eventName,
            "speakerName": speakerName,
            "eventDescription": eventDescription,
            "eventDate": eventDate,
            "memberID": currentUserID,
            "status": "Pending"
        ]
        
        // If an image is selected, upload it to Firebase Storage
        if let imageData = inputImageData {
            let storageRef = Storage.storage().reference().child("event_images/\(UUID().uuidString).jpg")
            let metadata = StorageMetadata()
            metadata.contentType = "image/jpeg"
            storageRef.putData(imageData, metadata: metadata) { (metadata, error) in
                guard let _ = metadata else {
                    print("Error uploading image: \(error)")
                    return
                }
                storageRef.downloadURL { (url, error) in
                    guard let downloadURL = url else {
                        print("Error retrieving image URL: \(error)")
                        return
                    }
                    // Update the event data with image URL
                    eventData["imageUrl"] = downloadURL.absoluteString
                    
                    // Add the event data to Firestore with image URL
                    let db = Firestore.firestore()
                    db.collection("eventRequests").addDocument(data: eventData) { error in
                        if let error = error {
                            print("Error adding document: \(error)")
                        } else {
                            print("Event request submitted successfully!")
                            // Clear all fields
                            eventName = ""
                            speakerName = ""
                            eventDescription = ""
                            eventDate = Date()
                            eventImage = nil
                            inputImageData = nil
                            
                            // Show alert
                            showingAlert = true
                        }
                    }
                }
            }
        } else {
            // If no image is selected, add the event data to Firestore without image URL
            let db = Firestore.firestore()
            db.collection("eventRequests").addDocument(data: eventData) { error in
                if let error = error {
                    print("Error adding document: \(error)")
                } else {
                    print("Event request submitted successfully!")
                    // Clear all fields
                    eventName = ""
                    speakerName = ""
                    eventDescription = ""
                    eventDate = Date()
                    eventImage = nil
                    
                    // Show alert
                    showingAlert = true
                }
            }
        }
    }
}

struct ImagePickerEvent: UIViewControllerRepresentable {
    @Binding var imageData: Data?

    func makeUIViewController(context: Context) -> some UIViewController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        var parent: ImagePickerEvent

        init(_ parent: ImagePickerEvent) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage, let imageData = uiImage.jpegData(compressionQuality: 0.8) {
                parent.imageData = imageData
            }
            picker.dismiss(animated: true)
        }
    }
}

struct UserEventRequestPage_Previews: PreviewProvider {
    static var previews: some View {
        UserEventRequestPage()
    }
}
