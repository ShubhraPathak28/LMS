//
//  ProfileScreen.swift
//  LMS_SD
//
//  Created by Sarthak Marwah on 25/04/24.
//

import SwiftUI
import SDWebImageSwiftUI
import Firebase
import FirebaseFirestore
import FirebaseFirestoreSwift
import FirebaseStorage
import Combine
import Foundation



struct Profile_Screen: View {
    
    // Define primaryPink color constant
    let primaryPink = Color(red: 0.9882352941176471, green: 0.7294117647058823, blue: 0.6784313725490196)
    
    // UID to fetch user details
    let uid: String = "user_uid_here" // Replace with actual UID
    
    // User details fetched from Firestore
    @State private var name: String?
    @State private var email: String?
    @State private var userType: String?
    @State private var isLoading = false
    
//    private var dobFormatted: String {
//        if let dob = dob {
//            let formatter = DateFormatter()
//            formatter.dateFormat = "dd/MM/yyyy"
//            return formatter.string(from: dob)
//        } else {
//            return "N/A"
//        }
//    }
    
    var body: some View {
        // Profile
        ZStack {
            Color(red: 242/255, green: 243/255, blue: 247/255)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Text("Profile")
                    .font(.custom("SF Pro", size: 24) .weight(.bold))
                    .foregroundColor(Color.black)
                    .offset(y: -10)
                
                if isLoading {
                    ProgressView()
                } else {
                    if let name = name, let email = email, let userType = userType {
                        VStack{
                            Image(systemName: "person.circle.fill")
                                .font(.custom("SF Pro", size: 74))
                                .foregroundColor(.black)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.white)
                                .frame(width: 340, height: 210)
                                .overlay(
                                    VStack(spacing: 20) {
                                        ProfileField(title: "Name", value: name, isLastField: false)
                                        Divider()
                                        ProfileField(title: "Email", value: email, isLastField: false)
                                        Divider()
                                        ProfileField(title: "User Type", value: userType, isLastField: true)
                                        
                                    }
                                    
                                    
                                )
                            QRCodeView()
                                .padding()
                                .padding(.top)
                        }
                    } else {
                        Text("User details not found.")
                            .foregroundColor(.black)
                            .font(.custom("SF Pro", size: 18))

                    }
                }
                
                Spacer() // Pushes the content to the top
            }
            .padding(.top, 30) // Adds padding to the top of VStack
            .onAppear {
                fetchUserDetails()
            }
        }
    }
    
    // Function to fetch user details from Firestore
    private func fetchUserDetails() {
        isLoading = true
        fetchUserData { userData in
            if let userData = userData {
                self.name = userData.name
                self.email = userData.email
                self.userType = userData.userType
                self.isLoading = false
            } else {
                print("User details not found.")
                self.isLoading = false
            }
        }
    }
    
    // Struct to hold user data
    struct UserData {
        let name: String
        let email: String
        let userType: String
    }
}

struct ProfileField: View {
    let title: String
    let value: String
    let isLastField: Bool
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text(title)
                    .font(.custom("SF Pro", size: 18))
                    .foregroundColor(Color.black)
                Spacer()
                Text(value)
                    .font(.custom("SF Pro", size: 18))
                    .foregroundColor(Color.black)
                    .padding(.leading, 20)
            }
            .padding(.horizontal, 20)
            if !isLastField {
                Rectangle()
                    .foregroundColor(Color.white)
                    .frame(width: 340, height: 1)
                    .offset(y: 12)
            }
        }
    }
}

struct Profile_Screen_Previews: PreviewProvider {
    static var previews: some View {
        Profile_Screen()
    }
}

// Function to fetch user data from Firestore
func fetchUserData(completion: @escaping (Profile_Screen.UserData?) -> Void) {
    if let uid = Auth.auth().currentUser?.uid {
        let db = Firestore.firestore()
        let userRef = db.collection("Users").document(uid)

        userRef.getDocument { document, error in
            if let error = error {
                print("Error fetching user details: \(error.localizedDescription)")
                completion(nil)
                return
            }
            
            guard let document = document, document.exists else {
                print("User document does not exist.")
                completion(nil)
                return
            }
            
            guard let data = document.data(),
                  let name = data["name"] as? String,
                  let email = data["email"] as? String,
                  let userType = data["userType"] as? String else {
                print("Error: User data is incomplete.")
                completion(nil)
                return
            }
            
//            let dob = dobTimestamp.dateValue()
            
            let userData = Profile_Screen.UserData(name: name, email: email, userType: userType)
            completion(userData)
        }
    } else {
        completion(nil)
    }
}

