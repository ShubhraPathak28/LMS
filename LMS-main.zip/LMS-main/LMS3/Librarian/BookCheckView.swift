//
//  BookCheckView.swift
//  LMS3
//
//  Created by Aditya Majumdar on 24/04/24.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth

struct BookCheckView: View {
    @State private var currentIssues: [BookInfo] = []
    @State private var returnedBooks: [BookInfo] = []
    @State private var todaysFine: Int = 0
    @State private var weeklyFine: Int = 0
    
    private let db = Firestore.firestore()
    
    var body: some View {
        NavigationView {
            VStack {
                // Book Availability Section
                VStack {
                    HStack(spacing: 20) {
                        NavigationLink(destination: CheckInView()) {
                            VStack {
                                Text("Check-In")
                                    .foregroundColor(.white)
                                    .padding()
                                    .bold()
                            }
                            .frame(width: 150, height: 75)
                            .background(Color(red: 228/255, green: 133/255, blue: 134/255))
                            .cornerRadius(10)
                        }
                        
                        NavigationLink(destination: CheckOutView()) {
                            VStack {
                                Text("Check-Out")
                                    .foregroundColor(.white)
                                    .padding()
                                    .bold()
                            }
                            .frame(width: 150, height: 75)
                            .background(Color(red: 228/255, green: 133/255, blue: 134/255))
                            .cornerRadius(10)
                        }
                    }
                    .navigationTitle("Book Availability")
                    .padding(.vertical, 20)
                    
                    
                    ScrollView{
                        VStack(alignment:.leading){
                            VStack(alignment:.leading){
                                Text("Fines")
                                    .font(.headline)
                                    .padding(.bottom,5)
                                    .padding(.leading)
                                
                                
                                
                                HStack{
                                    VStack(alignment:.center){
                                        
                                        Text("Today")
                                            .font(.title3).bold()
                                        
                                        Text("₹ \(todaysFine)")
                                            .font(.title).bold()
                                            .foregroundStyle(Color(red: 228/255, green: 133/255, blue: 134/255))
                                    }
                                        Spacer()
                                    
                                    VStack(alignment:.center){
                                        
                                        Text("Weekly")
                                            .font(.title3).bold()
                                        
                                        Text("₹ \(weeklyFine)")
                                            .font(.title).bold()
                                            .foregroundStyle(Color(red: 228/255, green: 133/255, blue: 134/255))
                                    }
                                        
                                    
                                }.padding(.horizontal,40)
                                
                    
                               
                            }.padding(.bottom,10)
                            
                            
                            // Current Issues
                            if !currentIssues.isEmpty {
                                VStack(alignment: .leading) {
                                    Text("Issued")
                                        .font(.headline)
                                        .padding(.bottom)
                                    ScrollView(.horizontal, showsIndicators: false) {
                                        HStack{
                                            ForEach(currentIssues) { book in
                                                BookItemViewLibrarian(book: book)
                                            }
                                        }
                                        .padding()
                                    }
                                }.padding(.leading)
                            }
                            
                            // Returned Books
                            if !returnedBooks.isEmpty {
                                VStack(alignment: .leading) {
                                    Text("Returned")
                                        .font(.headline)
                                        .padding(.bottom)
                                    ScrollView(.horizontal, showsIndicators: false) {
                                        HStack {
                                            ForEach(returnedBooks) { book in
                                                BookItemViewLibrarian(book: book)
                                            }
                                        }
                                        .padding()
                                    }
                                }
                                .padding(.leading)
                            }
                        }
                        .onAppear {
                            fetchBooks()
                            fetchFines()
                        }
                        Spacer()
                    }
                }
            }
        }
    }
    
    private func fetchFines() {
        let today = Date()
        let lastWeek = Calendar.current.date(byAdding: .day, value: -7, to: today)!
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        let todayString = dateFormatter.string(from: today)
        let lastWeekString = dateFormatter.string(from: lastWeek)
        
        // Debug prints
        print("Today: \(todayString)")
        print("Last week: \(lastWeekString)")
        
        // Fetch fine details for today
        db.collection("FineDetails")
            .whereField("Date", isEqualTo: todayString)
            .getDocuments { querySnapshot, error in
                if let error = error {
                    print("Error fetching today's fine: \(error.localizedDescription)")
                    return
                }
                guard let documents = querySnapshot?.documents else {
                    print("No documents found for today's fine")
                    return
                }
                var todayFineTotal: Double = 0.0
                for document in documents {
                    let data = document.data()
                    if let fineAmountString = data["fineAmount"] as? String,
                       let fineAmount = Double(fineAmountString) {
                        todayFineTotal += fineAmount
                    }
                }
                self.todaysFine = Int(todayFineTotal.rounded())
            }
        
        // Fetch fine details for last week
        // Fetch fine details for last week
        db.collection("FineDetails")
            .whereField("Date", isGreaterThanOrEqualTo: lastWeekString)
            .whereField("Date", isLessThanOrEqualTo: todayString)
            .getDocuments { querySnapshot, error in
                if let error = error {
                    print("Error fetching last week's fine: \(error.localizedDescription)")
                    return
                }
                guard let documents = querySnapshot?.documents else {
                    print("No documents found for last week's fine")
                    return
                }
                print("Documents for last week's fine: \(documents)")
                var lastWeekFineTotal: Double = 0.0
                for document in documents {
                    let data = document.data()
                    if let fineAmountString = data["fineAmount"] as? String,
                       let fineAmount = Double(fineAmountString) {
                        lastWeekFineTotal += fineAmount
                    }
                }
                self.weeklyFine = Int(lastWeekFineTotal.rounded())
            }
        
    }
    
    
    
    private func fetchBooks() {
        currentIssues.removeAll()
        returnedBooks.removeAll()
        db.collection("checkindetails")
            .whereField("ifcheckout", isEqualTo: "NO")
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching current issues: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                for document in documents {
                    let data = document.data()
                    let bookISBN = data["bookISBN"] as? String ?? ""
                    let issueDate = data["checkInDate"] as? String ?? ""
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "dd/MM/yyyy"
                    if let issueDateFormatted = dateFormatter.date(from: issueDate) {
                        let dueDate = Calendar.current.date(byAdding: .day, value: 7, to: issueDateFormatted)!
                        let issueDateString = dateFormatter.string(from: issueDateFormatted)
                        let dueDateString = dateFormatter.string(from: dueDate)
                        fetchBookInfo(bookISBN: bookISBN, issueDate: issueDateString, dueDate: dueDateString)
                    } else {
                        print("Error parsing issue date")
                    }
                }
            }
        
        // Fetch returned books
        db.collection("checkoutdetail")
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching returned books: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                for document in documents {
                    let data = document.data()
                    let bookISBN = data["bookISBN"] as? String ?? ""
                    let issueDate = data["checkInDate"] as? String ?? ""
                    let dueDate = data["dueDate"] as? String ?? ""
                    let returnDate = data["returnDate"] as? String ?? ""
                    fetchBookInfo(bookISBN: bookISBN, issueDate: issueDate, returnDate: returnDate, dueDate: dueDate)
                }
            }
    }
    
    private func fetchBookInfo(bookISBN: String, issueDate: String, dueDate: String) {
        db.collection("books")
            .whereField("isbn", isEqualTo: bookISBN) // Match by ISBN
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching book info: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                for document in documents {
                    let data = document.data()
                    let title = data["title"] as? String ?? ""
                    let author = data["authors"] as? [String] ?? []
                    let imageUrl = data["imageUrl"] as? String ?? ""
                    let isbn = data["isbn"] as? String ?? ""
                    let bookInfo = BookInfo(isbn: isbn, title: title, author: author, imageUrl: imageUrl, issueDate: issueDate, returnDate: nil, dueDate: dueDate)
                    DispatchQueue.main.async {
                        currentIssues.append(bookInfo)
                    }
                }
            }
    }
    
    private func fetchBookInfo(bookISBN: String, issueDate: String, returnDate: String, dueDate: String) {
        db.collection("books")
            .whereField("isbn", isEqualTo: bookISBN) // Match by ISBN
            .getDocuments { querySnapshot, error in
                guard let documents = querySnapshot?.documents else {
                    print("Error fetching book info: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                for document in documents {
                    let data = document.data()
                    let title = data["title"] as? String ?? ""
                    let isbn = data["isbn"] as? String ?? ""
                    let author = data["authors"] as? [String] ?? []
                    let imageUrl = data["imageUrl"] as? String ?? ""
                    let bookInfo = BookInfo(isbn: isbn,title: title, author: author, imageUrl: imageUrl, issueDate: issueDate, returnDate: returnDate, dueDate: dueDate)
                    DispatchQueue.main.async {
                        returnedBooks.append(bookInfo)
                    }
                }
            }
    }
}


#Preview {
    BookCheckView()
}
