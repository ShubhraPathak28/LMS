//
//  AddBookManually.swift
//  LMS3
//
//  Created by Aditya Majumdar on 24/04/24.
//

import SwiftUI
import SDWebImageSwiftUI
import Firebase
import FirebaseFirestore
import FirebaseFirestoreSwift
import FirebaseStorage

struct AddBookView: View {
    let db = Firestore.firestore()
    
    @State private var bookId: String = ""
    @State private var bookName: String = ""
    @State private var authorNames: [String] = []
    @State private var description: String = ""
    @State private var publication: String = ""
    @State private var publicationDate: String = ""
    @State private var category: String = "Fiction"
    @State private var quantity: Int = 1
    @State private var edition: String = ""
    @State private var bookImageData: Data? = nil
    @State private var showImagePicker = false
    @State private var imageUrl: String = ""
    @State private var price:Double = 0
    @State private var shelfNumber: String = ""
    @State private var showAlert = false
    
    var body: some View {
        ScrollView {
            VStack(alignment:.leading, spacing: 20) {
                Text("Add Book")
                    .font(.largeTitle).bold()
                    .padding(.top)
                
                Group {
                    HStack {
                        VStack(alignment:.leading) {
                            Text("Book Name")
                                .font(.headline)
                            LabeledTextField(text: $bookName)
                                .padding(.leading,-16)
                              
                        }
                        VStack(alignment:.leading) {
                            Text("Book Id")
                                .font(.headline)
                            LabeledTextField(text: $bookId)
                                .padding(.leading,-16)
                        }
                    }
                    
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Authors")
                                .font(.headline)
                                .padding(.bottom,40)

                            
                            ForEach(authorNames.indices, id: \.self) { index in
                                TextField("Author \(index + 1)", text: Binding(
                                    get: { self.authorNames[index] },
                                    set: { self.authorNames[index] = $0 }
                                ))
                                .padding()
                                .background(Color.gray.opacity(0.2))
                                .cornerRadius(10)
                                .padding(.horizontal)
                            }
                            
                            Button(action: {
                                self.authorNames.append("")
                            }){
                                Text("Add Author")
                                    .foregroundColor(.blue)
                                  //  .padding(.bottom)


                            }
                        }
                        VStack(alignment:.leading) {
                            Text("Edition")
                                .font(.headline)
                            LabeledTextField(text: $edition)
                                .padding(.leading,-16)

                        }
                    }
                    
                    VStack(alignment:.leading) {
                        Text("Description")
                            .font(.headline)
                        TextField("", text: $description)
                            .padding()
                            .background(Color.gray.opacity(0.2))
                            .cornerRadius(10)
                         //   .padding(.horizontal)
                    }
                }
                
                HStack {
                    VStack(alignment:.leading) {
                        Text("Publication")
                            .font(.headline)
                        LabeledTextField(text: $publication)
                            .padding(.leading,-16)
                    }
                    VStack(alignment:.leading) {
                        Text("Publication Date")
                            .font(.headline)
                        LabeledTextField(text: $publicationDate)
                            .padding(.leading,-15)
                            .padding(.trailing,-16)
                    }
                }
                
                HStack(spacing: 20) {
                    VStack(alignment: .leading) {
                        Text("Price")
                            .font(.headline)
                        LabeledTextField(text: Binding<String>(
                            get: { String(price) },
                            set: { newValue in
                                if let value = Double(newValue) {
                                    price = value
                                }
                            }
                        ))                    .padding(.leading,-15)
                                          .padding(.trailing,-10)


                    }
                    VStack(alignment:.leading) {
                        Text("Shelf Number")
                            .font(.headline)
                        LabeledTextField(text: $shelfNumber)
                            .padding(.leading,-15)
                            .padding(.trailing,-10)
                    }
                }

                
                HStack(spacing: 20) {
                    VStack(alignment:.leading) {
                        Text("Category")
                            .font(.headline)
                        CategoryPicker(category: $category)
                    }
                    Spacer()
                    VStack(alignment:.trailing) {
                        Text("Quantity")
                            .font(.headline)
                            .padding(.leading,-170)
                        HStack {
                            Stepper(value: $quantity, in: 0...100) {
                                EmptyView()
                            }.padding(.leading,-170)
                            Text("\(quantity)").padding(.leading,-170)
                        }
                    }
                }
                
                HStack {
                    VStack {
                        Text("Book photo")
                            .bold()
                            .padding(.leading,120)
                        if let imageData = bookImageData {
                            Image(uiImage: UIImage(data: imageData)!)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                                .clipped()
                                .cornerRadius(10)
                                .onTapGesture {
                                    self.showImagePicker = true
                                }
                        } else {
                            Button(action: {
                                self.showImagePicker = true
                            }) {
//                                Text("Select Image")
//                                    .padding(.leading,-170)
                                Image(systemName: "square.and.arrow.up")
                                  .padding(.leading,120)
                                  .padding(.top,7)

                            }
                        }
                    }
                    .sheet(isPresented: $showImagePicker) {
                        ImagePickerBook(imageData: self.$bookImageData)
                    }
                }
                
                Button(action: {
                    uploadBook()
                    showAlert = true
                    
                }) {
                    Text("Add Book")
                        .foregroundColor(.white)
                        .frame(maxWidth:.infinity)
                        .padding()
                        .background(Color("Pink"))
                        .cornerRadius(15)
                }
                .padding(.bottom)
            }
            .padding()
        }
        .alert(isPresented: $showAlert) {
                    Alert(title: Text("Success"), message: Text("Book Added Successfully."), dismissButton: .default(Text("OK")))
                }
        .background(Color.white)
        .cornerRadius(40)
    }
    
    func uploadBook() {
            // Create a new book document
            var newBook: [String: Any] = [
                "id": bookId,
                "isbn": bookId,
                            "title": bookName,
                            "authors": authorNames,
                            "description": description,
                            "publisher": publication,
                            "publicationDate": publicationDate,
                            "genre": category,
                            "selectedCategory": category,
                            "quantity": quantity,
                            "availability": quantity,
                            "edition": edition,
                            "authorImageUrl": "",
                "price": price,
                "shelfNumber": shelfNumber
                
            ]
            
            // Upload image to Firestore Storage if imageData exists
            if let imageData = bookImageData {
                uploadImageToStorage(imageData: imageData) { imageUrl in
                    newBook["imageUrl"] = imageUrl
                    
                    // Add the new book document to Firestore
                    self.addBookToFirestore(bookData: newBook)
                }
            } else {
                // Add the new book document to Firestore without image
                self.addBookToFirestore(bookData: newBook)
            }
        }
        
        func uploadImageToStorage(imageData: Data, completion: @escaping (String) -> Void) {
            let storageRef = Storage.storage().reference().child("book_images/\(UUID().uuidString).jpg")
            
            storageRef.putData(imageData, metadata: nil) { (_, error) in
                if let error = error {
                    print("Error uploading image: \(error.localizedDescription)")
                    return
                }
                
                storageRef.downloadURL { (url, error) in
                    if let downloadURL = url?.absoluteString {
                        completion(downloadURL)
                    }
                }
            }
        }
        
        func addBookToFirestore(bookData: [String: Any]) {
            // Add a new document with a generated ID
            db.collection("books").addDocument(data: bookData) { error in
                if let error = error {
                    print("Error adding document: \(error.localizedDescription)")
                } else {
                    print("Book added successfully!")
                    // Clear form fields after successful upload
                    bookId = ""
                    bookName = ""
                    authorNames = []
                    description = ""
                    publication = ""
                    publicationDate = ""
                    category = "Fiction"
                    quantity = 1
                    edition = ""
                    imageUrl = ""
                    bookImageData = nil
                    price = 0
                    shelfNumber = ""
                }
            }
        }
    }

struct LabeledTextField: View {
    @Binding var text: String
    
    var body: some View {
        TextField("", text: $text)
            .padding()
            .background(Color.gray.opacity(0.2))
            .cornerRadius(10)
            .padding(.horizontal)
    }
}

struct DatePickerWithIcon: View {
    @Binding var date: Date
    
    var body: some View {
        HStack {
            Image(systemName: "calendar")
                .foregroundColor(.gray)
            DatePicker("",
                       selection: $date,
                       displayedComponents:.date)
        }
        .padding()
        .background(Color.gray.opacity(0.2))
        .cornerRadius(10)
    }
}

struct CategoryPicker: View {
    @Binding var category: String
    @State private var categories: [String] = []

    var body: some View {
        Picker("Category", selection: $category) {
            ForEach(categories, id: \.self) { categoryName in
                Text(categoryName).tag(categoryName)
            }
        }
        .pickerStyle(MenuPickerStyle())
        .background(Color.gray.opacity(0.2))
        .cornerRadius(10)
        .onAppear {
            fetchCategories()
        }
    }

    func fetchCategories() {
        // Assuming you have a Firestore database and a 'categories' collection
        let db = Firestore.firestore()
        db.collection("categories").getDocuments { querySnapshot, error in
            if let error = error {
                print("Error getting documents: \(error)")
            } else {
                categories = querySnapshot?.documents.compactMap { $0.data()["name"] as? String } ?? []
            }
        }
    }
}

struct ImagePickerBook: UIViewControllerRepresentable {
    @Binding var imageData: Data?

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        var parent: ImagePickerBook

        init(parent: ImagePickerBook) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.imageData = image.jpegData(compressionQuality: 0.5) // Convert to JPEG data with compression
            }
            picker.dismiss(animated: true, completion: nil)
        }
    }
}


struct AddBookView_Previews: PreviewProvider {
    static var previews: some View {
        AddBookView()
    }
}
