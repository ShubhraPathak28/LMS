import SwiftUI
import AVFoundation
import SDWebImageSwiftUI
import FirebaseFirestore

struct BookScannerView: View {
    let category: Category

    var body: some View {
        BarcodeScannerViewController(category: category)
            .edgesIgnoringSafeArea(.all)
    }
}

struct BarcodeScannerViewController: UIViewControllerRepresentable {
    let category: Category

    func makeUIViewController(context: Context) -> UIViewController {
        let viewController = ViewController()
        viewController.category = category
        return viewController
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
        // Update view controller if needed
    }
}

class ViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    let db = Firestore.firestore()
    var category: Category?
    @State private var showAlert = false
    @State private var alertMessage = ""


    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
    }
    func showAlert(message: String) {
            self.alertMessage = message
            self.showAlert = true
        }
    private func showSuccessAlert() {
            showAlert(message: "Document updated successfully!")
        }

        private func showErrorAlert(message: String) {
            showAlert(message: "Error: \(message)")
        }

    func setupCamera() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }

            self.captureSession = AVCaptureSession()

            guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else {
                print("Failed to get video capture device")
                return
            }

            do {
                let videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
                if self.captureSession.canAddInput(videoInput) {
                    self.captureSession.addInput(videoInput)
                } else {
                    print("Failed to add video input to capture session")
                    return
                }

                let metadataOutput = AVCaptureMetadataOutput()
                if self.captureSession.canAddOutput(metadataOutput) {
                    self.captureSession.addOutput(metadataOutput)

                    metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
                    metadataOutput.metadataObjectTypes = [.ean13, .ean8]

                    DispatchQueue.main.async { [weak self] in
                        self?.previewLayer = AVCaptureVideoPreviewLayer(session: self!.captureSession)
                        self?.previewLayer.frame = self!.view.layer.bounds
                        self?.previewLayer.videoGravity = .resizeAspectFill
                        self?.view.layer.addSublayer(self!.previewLayer)
                        
                        self?.captureSession.startRunning()
                    }
                } else {
                    print("Failed to add metadata output to capture session")
                    return
                }
            } catch {
                print("Error setting up camera: \(error.localizedDescription)")
            }
        }
    }

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard let metadataObject = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
              let isbn = metadataObject.stringValue else {
            print("No valid ISBN found")
            return
        }

        stopBarcodeScanning() // Stop scanning after successful read
        fetchBookDetails(isbn: isbn)
    }

    func fetchBookDetails(isbn: String) {
            let apiUrl = "https://www.googleapis.com/books/v1/volumes?q=isbn:\(isbn)&key=AIzaSyCHRRJX1Ai7Bad9e170t75r7dtRg-5kbxc"
    
            guard let url = URL(string: apiUrl) else {
                    print("Invalid API URL")
                    return
                }
    
        URLSession.shared.dataTask(with: url) { [weak self] (data, response, error) in
                guard let data = data else {
                    print("No data received")
                    return
                }
                
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                    
                    if let items = json?["items"] as? [[String: Any]], let volumeInfo = items.first?["volumeInfo"] as? [String: Any] {
                        let title = volumeInfo["title"] as? String ?? "Unknown Title"
                        let authors = volumeInfo["authors"] as? [String] ?? []
                        let edition = volumeInfo["edition"] as? String ?? "Unknown Edition"
                        let publicationDate = volumeInfo["publishedDate"] as? String ?? "Unknown"
                        let genres = volumeInfo["categories"] as? [String] ?? []
                        let genre = genres.joined(separator: ", ")
                        let publisher = volumeInfo["publisher"] as? String ?? "Unknown Publisher"
                        let description = volumeInfo["description"] as? String ?? "No description available"
                        
                        var imageUrl: String?
                        if let imageLinks = volumeInfo["imageLinks"] as? [String: Any], let thumbnail = imageLinks["thumbnail"] as? String {
                            imageUrl = thumbnail
                        }
                        
                        // Fetch book price from saleInfo
                        let saleInfo = items.first?["saleInfo"] as? [String: Any]
                        let listPrice = saleInfo?["listPrice"] as? [String: Any]
                        let price = listPrice?["amount"] as? Double ?? 0.0
                        
                        var authorImageUrl: String?
                        if let authors = volumeInfo["authors"] as? [String], let author = authors.first {
                            // Fetch author's image URL using the author's name
                            authorImageUrl = self?.fetchAuthorImage(author: author)
                        }
                        
                        let book = BookDetails(title: title, authors: authors, publicationDate: publicationDate, genre: genre, edition: edition, isbn: isbn, publisher: publisher, description: description, imageUrl: imageUrl, authorImageUrl: authorImageUrl, price: price)
                        
                        DispatchQueue.main.async {
                            // Pass authorImageUrl and price to the saveBookToFirestore function
                            self?.saveBookToFirestore(book: book, authorImageUrl: authorImageUrl, price: price)
                        }
                    } else {
                        print("Book details not found for ISBN: \(isbn)")
                    }
                } catch {
                    print("Error parsing JSON: \(error.localizedDescription)")
                }
            }.resume()
        }
    
            // Function to fetch author's image URL using Google Knowledge Graph API
            func fetchAuthorImage(author: String) -> String? {
                let encodedAuthor = author.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                let knowledgeGraphApiUrl = "https://kgsearch.googleapis.com/v1/entities:search?query=\(encodedAuthor)&key=AIzaSyCHRRJX1Ai7Bad9e170t75r7dtRg-5kbxc&limit=1&types=Person"
    
                guard let kgUrl = URL(string: knowledgeGraphApiUrl) else {
                    print("Invalid Google Knowledge Graph API URL")
                    return nil
                }
    
                var authorImageUrl: String?
                if let kgData = try? Data(contentsOf: kgUrl),
                   let kgJson = try? JSONSerialization.jsonObject(with: kgData, options: []) as? [String: Any],
                   let itemList = kgJson["itemListElement"] as? [[String: Any]],
                   let authorEntity = itemList.first?["result"] as? [String: Any],
                   let detailedDescription = authorEntity["detailedDescription"] as? [String: Any],
                   let imageUrl = detailedDescription["url"] as? String {
                    authorImageUrl = imageUrl
                }
    
                return authorImageUrl
            }
    

    private func saveBookToFirestore(book: BookDetails, authorImageUrl: String?, price: Double) {
        guard let category = category else { return }

        let booksRef = db.collection("books")
        let query = booksRef.whereField("isbn", isEqualTo: book.isbn)

        query.getDocuments { [weak self] (querySnapshot, error) in
            guard let self = self else { return }

            if let error = error {
                print("Error querying documents: \(error.localizedDescription)")
                self.showErrorAlert(message: error.localizedDescription)
                return
            }

            if let snapshot = querySnapshot, !snapshot.isEmpty {
                self.showSuccessAlert()
                // If a document with the same ISBN exists, update its quantity
                if let document = snapshot.documents.first {
                    var data = document.data()
                    if var quantity = data["quantity"] as? Int {
                        quantity += 1
                        data["quantity"] = quantity
                        document.reference.updateData(data) { error in
                            if let error = error {
                                print("Error updating document: \(error.localizedDescription)")
                            } else {
                                print("Document updated successfully!")
                                self.showSuccessAlert()
                            }
                        }
                    }
                    if var availability = data["availability"] as? Int {
                        availability += 1
                        data["availability"] = availability
                        document.reference.updateData(data) { error in
                            if let error = error {
                                print("Error updating document: \(error.localizedDescription)")
                            } else {
                                print("Document updated successfully!")
                                self.showSuccessAlert()
                            }
                        }
                    }
                }
            } else {
                // If no document with the same ISBN exists, add a new document
                var data: [String: Any] = [
                    "id": book.isbn,
                    "title": book.title,
                    "authors": book.authors,
                    "quantity": 1,
                    "availability": 1,
                    "edition": book.edition,
                    "publicationDate": book.publicationDate,
                    "genre": book.genre,
                    "isbn": book.isbn,
                    "publisher": book.publisher,
                    "description": book.description,
                    "imageUrl": book.imageUrl ?? "",
                    "selectedCategory": category.name,
                    "price": price,
                    "shelfNumber": ""
                ]

                if let authorImageUrl = authorImageUrl {
                    data["authorImageUrl"] = authorImageUrl
                }

                booksRef.addDocument(data: data) { error in
                    if let error = error {
                        print("Error adding document: \(error.localizedDescription)")
                    } else {
                        print("Document added successfully!")
                        self.showSuccessAlert()
                    }
                }
            }
        }
    }

    func stopBarcodeScanning() {
        guard let captureSession = captureSession, captureSession.isRunning else { return }
        captureSession.stopRunning()
    }

    func startBarcodeScanning() {
        guard let captureSession = captureSession, !captureSession.isRunning else { return }
        captureSession.startRunning()
    }
}



struct BookDetails {
    let title: String
    let authors: [String]
    let publicationDate: String
    let genre: String
    let edition: String
    let isbn: String
    let publisher: String
    let description: String
    let imageUrl: String?
    let authorImageUrl: String?
    let price: Double
}
