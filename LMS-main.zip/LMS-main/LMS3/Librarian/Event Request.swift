//
//  Event Request.swift
//  LMS3
//
//  Created by Aditya Majumdar on 29/04/24.
//


import SwiftUI
import FirebaseFirestore
import SDWebImageSwiftUI

// Define the model for an event request
struct EventRequest: Identifiable {
    var id = UUID()
    var eventName: String
    var eventDate: Date
    var eventDescription: String
    var imageUrl: String // URL for the image
    var memberID: String // UID of the member who requested the event
    var speakerName: String
    var status: EventStatus // Accepted, Rejected, or Pending
    var description: String
    var hasDescription: Bool {
            // Check if the description is not empty
            !description.isEmpty
        }
}

enum EventStatus: String {
    case accepted = "Accepted"
    case rejected = "Rejected"
    case pending = "Pending"
}

// Main view that lists all event requests
struct EventRequestsView: View {
    @StateObject var viewModel = EventRequestsViewModel()
    @State var isLoading = true
    @State private var showingCalendarPage = false
    let notify = NotificationHandler()

    var body: some View {
        VStack() {
            HStack{
                Text("Event Requests")
                    .font(.largeTitle).bold()
                    .padding()
                    .padding(.bottom)
            Spacer()
                    Button(action: {
                        showingCalendarPage.toggle()
                    }) {
                        Image(systemName: "calendar")
                            .font(.title)
                            .padding()
                    }
            }
            
            if isLoading {
                ProgressView("Loading...")
            } else {
                if viewModel.eventRequests.isEmpty {
                    Text("No current requests")
                } else {
                    NavigationView {
                        ScrollView{
                            VStack{
                                ForEach(viewModel.eventRequests) { eventRequest in
                                    EventRequestRow(eventRequest: eventRequest)
                                        .padding(.vertical, 5)
                                }
                            }
                        }
                    }
                }
            }
            Spacer()
        }
        .onAppear {
            notify.askPermission()
            viewModel.fetchEventRequests()
        }
        .onChange(of: viewModel.isLoading) { newValue in
            isLoading = newValue
        }
        .sheet(isPresented: $showingCalendarPage) {
            CalendarLibrarian()
        }
    }
}

class EventRequestsViewModel: ObservableObject {
    @Published var eventRequests: [EventRequest] = []
    @Published var isLoading = true

    // Fetch event requests from Firestore
    func fetchEventRequests() {
        isLoading = true
        let db = Firestore.firestore()
        db.collection("eventRequests")
            .whereField("status", isEqualTo: "Pending")
            .getDocuments { querySnapshot, error in
                self.isLoading = false
                if let error = error {
                    print("Error fetching event requests: \(error)")
                } else {
                    if let documents = querySnapshot?.documents {
                        self.eventRequests = documents.compactMap { queryDocumentSnapshot in
                            let data = queryDocumentSnapshot.data()
                            return EventRequest(
                                eventName: data["eventName"] as? String ?? "",
                                eventDate: (data["eventDate"] as? Timestamp)?.dateValue() ?? Date(),
                                eventDescription: data["eventDescription"] as? String ?? "",
                                imageUrl: data["imageUrl"] as? String ?? "",
                                memberID: data["memberID"] as? String ?? "",
                                speakerName: data["speakerName"] as? String ?? "",
                                status: EventStatus(rawValue: data["status"] as? String ?? "") ?? .pending,
                                description: data["description"] as? String ?? ""
                            )
                        }
                    }
                }
            }
    }
}

struct EventRequestRow: View {
    @ObservedObject var viewModel = EventRequestsViewModel()
    @State var eventRequest: EventRequest
    @State private var isAccepted = false
    @State private var isRejected = false
    @State private var descriptionInput = ""
    @State private var showingDescriptionSheet = false
    let notify = NotificationHandler()

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack {
                if let url = URL(string: eventRequest.imageUrl) {
                    WebImage(url: url)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 280, height: 180)
                        .cornerRadius(10)
                }

                VStack(alignment: .leading, spacing: 3) {
                    Text(eventRequest.eventName)
                        .font(.headline)
                        .foregroundColor(.primary)

                    Text("Date: \(eventRequest.eventDate, style: .date)")
                        .font(.subheadline)
                        .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))

                    Text(eventRequest.eventDescription)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                        .lineLimit(4)
                }
                .padding(.horizontal)
                .onTapGesture {
                                    showingDescriptionSheet = true
                                }
                
                // Display accepted or rejected text based on status
                if isAccepted {
                    Text("Accepted")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(10)
                        .padding(.top, 5)
                } else if isRejected {
                    Text("Rejected")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.red)
                        .cornerRadius(10)
                        .padding(.top, 5)
                } else if eventRequest.status == .pending {
                    // Display accept and reject buttons only for pending requests
                    HStack {
                        Button("Accept") {
                            updateStatus(to: .accepted)
                            notify.sendNotification(
                                date: Date(),
                                type: "time",
                                timeInterval: 10,
                                title: "New Event",
                                body: " a new event coming your way! See you there! #\(eventRequest.eventName)")
                        }
                        .buttonStyle(BorderedButtonStyle())
                        .foregroundColor(.white)
                        .frame(width: 80, height: 35)
                        .background(Color(red: 228/255, green: 133/255, blue: 134/255))
                        .cornerRadius(10)
                        .padding(.bottom, 2)
                        .padding(.horizontal)

                        Spacer()

                        Button("Reject") {
                            updateStatus(to: .rejected)
                        }
                        .frame(width: 80, height: 40)
                        .buttonStyle(BorderedButtonStyle())
                        .tint(.red)
                        .cornerRadius(10)
                    }
                    .padding(.horizontal)
                }
            }
            .padding()
            .frame(width: 300)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.gray, lineWidth: 0.8)
            )
            .opacity(eventRequest.status != .pending ? 0.3 : 1)
            .sheet(isPresented: $showingDescriptionSheet) {
                            DescriptionSheet(eventRequest: eventRequest, isPresented: $showingDescriptionSheet)
                        }
        }
    }
    
    // Update event request status
    private func updateStatus(to status: EventStatus) {
           let db = Firestore.firestore()
           
           // Query Firestore for documents with the specified eventName and memberId
           db.collection("eventRequests")
               .whereField("eventName", isEqualTo: eventRequest.eventName)
               .whereField("memberID", isEqualTo: eventRequest.memberID)
               .getDocuments { querySnapshot, error in
                   if let error = error {
                       print("Error searching for document: \(error)")
                   } else {
                       guard let document = querySnapshot?.documents.first else {
                           print("No document found with matching criteria")
                           return
                       }
                       
                       // Update the status field of the found document
                       let documentRef = document.reference
                       documentRef.updateData(["status": status.rawValue]) { error in
                           if let error = error {
                               print("Error updating status: \(error)")
                           } else {
                               print("Status updated successfully")
                               // Update local state to display accepted or rejected text
                               if status == .accepted {
                                   isAccepted = true
                               } else if status == .rejected {
                                   isRejected = true
                               }
                               // Remove the event request from the array
                               self.viewModel.eventRequests.removeAll(where: { $0.id == self.eventRequest.id })
                           }
                       }
                   }
               }
       }
}

struct DescriptionSheet: View {
    var eventRequest: EventRequest
    @Binding var isPresented: Bool
    @State private var descriptionInput = ""
    
    var body: some View {
        VStack {
            Text("Comment")
                .font(.headline).bold()
                .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255))
                .padding()
            
            TextEditor(text: $descriptionInput)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
                .padding()
            
            Button("Save") {
                saveDescription()
            }
            .padding()
            .foregroundColor(Color(red: 228/255, green: 133/255, blue: 134/255)) 
        }
    }
    
    
    private func saveDescription() {
        // Save the description to Firestore
        let db = Firestore.firestore()
        db.collection("eventRequests")
            .whereField("eventName", isEqualTo: eventRequest.eventName)
            .whereField("memberID", isEqualTo: eventRequest.memberID)
            .getDocuments { querySnapshot, error in
                if let error = error {
                    print("Error fetching documents: \(error)")
                } else {
                    guard let document = querySnapshot?.documents.first else {
                        print("No document found with matching criteria")
                        return
                    }
                    let documentRef = document.reference
                    documentRef.updateData(["description": descriptionInput]) { error in
                        if let error = error {
                            print("Error updating description: \(error)")
                        } else {
                            print("Description updated successfully")
                            // Dismiss the sheet
                            isPresented = false
                        }
                    }
                }
            }
    }
}


// Preview provider for SwiftUI previews in Xcode
struct EventRequestsView_Previews: PreviewProvider {
    static var previews: some View {
        EventRequestsView()
    }
}
