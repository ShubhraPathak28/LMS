//
//  BookItemLibrarian.swift
//  LMS3
//
//  Created by Aditya Majumdar on 05/05/24.
//

import SwiftUI
import FirebaseFirestore
import FirebaseAuth


struct BookItemViewLibrarian: View {
    let book: BookInfo
    @State private var bookImage: UIImage?
    @State private var rating: Int = 0
    var body: some View {
        VStack(alignment: .leading) {
            HStack(spacing:50){
                if let image = bookImage {
                    Image(uiImage: image)
                        .resizable()
                        .frame(width: 100, height: 160)
                        .cornerRadius(5.0)
                } else {
                    ProgressView()
                        .frame(width: 100, height: 160)
                        .cornerRadius(5.0)
                }
                VStack(alignment: .leading) {
                    Text(book.title)
                        .foregroundStyle(Color(red: 228/255, green: 133/255, blue: 134/255)) // Set text color to pink
                        .bold()
                        .font(.headline)
                    if book.author.count > 1 {
                        ForEach(book.author, id: \.self) { author in
                            Text(author)
                                .font(.subheadline)
                                .foregroundStyle(Color.gray)
                        }
                    } else {
                        Text(book.author.first ?? "")
                            .font(.subheadline)
                            .foregroundStyle(Color.gray)
                    }
                    
                    VStack(alignment:.leading,spacing:-5.5){
                        HStack{
                            Circle()
                                .frame(width: 10, height:10)
                            Text(" \(book.issueDate)")
                                .font(.subheadline)
                        }
                        Rectangle()
                            .strokeBorder(lineWidth: 1)
                            .fill(Color.gray)
                            .frame(width: 1, height: 25)
                            .padding(.leading,4.5)
                        if let returnDate = book.returnDate {
                            HStack{
                                Circle()
                                
                                    .fill(Color.green)
                                    .frame(width: 10, height:10)
                                Text(" \(returnDate)")
                                    .font(.subheadline)
                            }
                        }
                        else{
                            HStack{
                                Circle()
                                    .fill(Color.red)
                                    .frame(width: 10, height:10)
                                Text(" \(book.dueDate)")
                                    .font(.subheadline)
                            }
                        }
                    }
                }
                .padding(.leading, 10)
            }
        }.frame(width:340,alignment: .leading)
        .onAppear {
            loadImage()
        }
    }
    
    private func loadImage() {
        guard let imageUrl = URL(string: book.imageUrl) else { return }

        URLSession.shared.dataTask(with: imageUrl) { data, response, error in
            guard let data = data, error == nil else {
                if let error = error {
                    print("Error fetching image: \(error)")
                } else {
                    print("Unknown error fetching image")
                }
                return
            }

            DispatchQueue.main.async {
                self.bookImage = UIImage(data: data)
            }
        }.resume()
    }
}
