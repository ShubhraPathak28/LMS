//
//  Checkout.swift
//  LMS3
//
//  Created by Aditya Majumdar on 24/04/24.
//

import Foundation
import Firebase
import FirebaseFirestore

import AVFoundation

struct CheckoutDetails {
    let userID: String
    let bookID: String
    let date: Date
}
//checkout
extension ViewController {
    
    //checkout
    func saveCheckoutToFirestore(checkoutDetails: CheckoutDetails) {
        let checkoutRef = db.collection("checkoutdetail")
        
        let data: [String: Any] = [
            "userID": checkoutDetails.userID,
            "bookID": checkoutDetails.bookID,
            "date": Timestamp(date: checkoutDetails.date)
        ]
        
        checkoutRef.addDocument(data: data) { error in
            if let error = error {
                print("Error adding checkout detail document: \(error.localizedDescription)")
            } else {
                print("Checkout detail document added successfully!")
            }
        }
    }
    //checkin
    
    func deleteDocumentFromFirestore(userID: String, bookID: String) {
        // Construct a reference to the Firestore collection
        let collectionRef = db.collection("checkoutdetail")
        
        // Construct a query to find the document with the given userID and bookID
        let query = collectionRef.whereField("userID", isEqualTo: userID)
                                 .whereField("bookID", isEqualTo: bookID)

        // Execute the query
        query.getDocuments { (querySnapshot, error) in
            if let error = error {
                // Handle error
                print("Error getting documents: \(error)")
                return
            }
            
            guard let documents = querySnapshot?.documents else {
                print("No documents found")
                return
            }
            
            // Iterate over the documents found by the query
            for document in documents {
                // Delete each document found
                document.reference.delete { error in
                    if let error = error {
                        // Handle error while deleting
                        print("Error deleting document: \(error)")
                    } else {
                        // Document successfully deleted
                        print("Document successfully deleted")
                    }
                }
            }
        }
    }

    func scanBookBarcode() {
        guard captureSession?.isRunning == true else {
            print("Capture session is not running")
            return
        }
        // Set metadataObjectTypes to only scan book barcodes
        captureSession.outputs.forEach { output in
            if let metadataOutput = output as? AVCaptureMetadataOutput {
                metadataOutput.metadataObjectTypes = [.ean13, .ean8]
            }
        }
    }

    func scanUserIDBarcode() {
        guard captureSession?.isRunning == true else {
            print("Capture session is not running")
            return
        }
        // Set metadataObjectTypes to only scan user ID barcodes
        captureSession.outputs.forEach { output in
            if let metadataOutput = output as? AVCaptureMetadataOutput {
                // Assuming your user ID barcodes have a different type, set it here
                metadataOutput.metadataObjectTypes = [.code128] // Change as per your barcode type
            }
        }
    }
}
