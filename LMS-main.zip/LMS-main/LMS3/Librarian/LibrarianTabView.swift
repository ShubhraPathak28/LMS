//
//  LibrarianTabView.swift
//  LMS3
//
//  Created by Aditya Majumdar on 26/04/24.
//

import SwiftUI


struct librarianTabView: View {
    var body: some View {
        // Member-specific profile view
      
            TabView{
                Group{
                    
                        LibrarianHomeView()
                        .tabItem {  Label("Home", systemImage: "house.fill") }

                    
                        BookCheckView()
                        .tabItem {  Label("Catalog", systemImage: "books.vertical") }

                    
                    EventRequestsView()
                    .tabItem {  Label("Calendar", systemImage: "calendar") }
                    
                    Analytics()
                        .tabItem {  Label("Analytics", systemImage: "chart.bar.xaxis") }
                    

                    
                    
                }
               
               
            }.accentColor(Color("Pink"))
        }
    
}



#Preview {
    librarianTabView()
}
