//
//  ContentView.swift
//  LocalNotifications
//
//  Created by Sarthak Marwah on 03/05/24.
//

import SwiftUI

struct PushNotificationView: View {
    @State private var selectedDate = Date()
    let notify = NotificationHandler()
    
    var body: some View {
        VStack(spacing: 20){
            Spacer()
            Button("BookWise Testing - notification in 5 seconds"){
                notify.sendNotification(
                    date: Date(),
                    type: "time",
                    timeInterval: 5,
                    title: "Hey! - Time",
                    body: "This is the reminder you set 5 seconds ago!")
            }
            
            DatePicker("Pick a date: ", selection: $selectedDate, in: Date()...)
            Button("Schedule Notification"){
                notify.sendNotification(
                    date: selectedDate,
                    type: "date",
                    timeInterval: 5,
                    title: "Hey! - Date",
                    body: "This is the reminder you set using Date Picker")
            }.tint(.red)
            
            Spacer()
//            Text("Not working?")
//                .foregroundColor(.gray)
//                .italic()
//            Button("Request permissions"){
//                notify.askPermission()
//            }
        }
        .onAppear {
                    notify.askPermission()
                }
        .padding()
    }
}

#Preview {
    PushNotificationView()
}
